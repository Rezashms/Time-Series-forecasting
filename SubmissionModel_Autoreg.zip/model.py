import os
import tensorflow as tf
import numpy as np

class model:

    def __init__(self, path):
        self.model = tf.keras.models.load_model(os.path.join(path, 'SubmissionModel'))

    def predict(self, X, categories):      
        
        window = 60
        X = X[:, -window:]
        reg_future = np.array([])
        X = np.expand_dims(X, axis=-1)
        X_temp = X
        for reg in range(0,18,9):
            pred_temp = self.model.predict(X_temp)
            if(len(reg_future)==0):
                reg_future = pred_temp
            else:
                reg_future = np.concatenate((reg_future,pred_temp),axis=1) # Append the prediction to the whole forecasting
            X_temp = np.concatenate((X_temp[:,9:,:],pred_temp), axis=1)
        
        out = np.squeeze(reg_future, axis=-1)
            
        return out